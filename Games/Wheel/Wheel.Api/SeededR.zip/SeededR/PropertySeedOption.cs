﻿public class PropertySeedOption
{
    public string PropertyName { get; set; }
    public List<object> Values { get; set; }
    public PropertySeedOptionType PropertySeedOptionType { get; set; }
}