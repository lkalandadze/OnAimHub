﻿public enum PropertySeedOptionType
{
    Single,
    InNumberRange,
    FromList,
    Random
}